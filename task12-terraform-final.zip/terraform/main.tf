# -------------------------------------------------------------------
# Existing/default VPC
# -------------------------------------------------------------------

data "aws_vpc" "default" {
  default = true
}

# Select an existing default subnet from the default VPC.
data "aws_subnets" "default" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.default.id]
  }

  filter {
    name   = "default-for-az"
    values = ["true"]
  }
}

# -------------------------------------------------------------------
# Security group for Twenty CRM
# -------------------------------------------------------------------

resource "aws_security_group" "twenty_crm" {
  name        = "${var.instance_name}-sg"
  description = "Security group for Twenty CRM Task 12"
  vpc_id      = data.aws_vpc.default.id

  # SSH access restricted to the administrator's current public IP.
  ingress {
    description = "SSH from administrator"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["${var.admin_ip}/32"]
  }

  # Twenty CRM web interface.
  ingress {
    description = "Twenty CRM"
    from_port   = 2020
    to_port     = 2020
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }

  # Allow the instance to reach the internet for package installation,
  # ECR authentication, and image pulling.
  egress {
    description = "Allow outbound traffic"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${var.instance_name}-sg"
  }
}

# -------------------------------------------------------------------
# Amazon ECR repository
# -------------------------------------------------------------------

resource "aws_ecr_repository" "twenty_crm" {
  name                 = var.ecr_repository_name
  image_tag_mutability = "MUTABLE"

  image_scanning_configuration {
    scan_on_push = true
  }

  tags = {
    Name = var.ecr_repository_name
  }
}

# -------------------------------------------------------------------
# EC2 instance
# -------------------------------------------------------------------

resource "aws_instance" "twenty_crm" {
  ami                         = var.ami_id
  instance_type               = var.instance_type
  subnet_id                   = data.aws_subnets.default.ids[0]
  associate_public_ip_address = true

  vpc_security_group_ids = [
    aws_security_group.twenty_crm.id
  ]

  # KodeKloud provides this pre-existing IAM instance profile.
  # It already has AmazonEC2ContainerRegistryReadOnly attached.
  iam_instance_profile = "EC2ECRPullRole"

  # EC2 User Data installs Docker, authenticates to ECR,
  # retries the image pull, and starts Twenty CRM.
  user_data = templatefile("${path.module}/user_data.sh", {
    aws_region       = var.aws_region
    ecr_repository   = aws_ecr_repository.twenty_crm.repository_url
    image_tag        = var.image_tag
    container_name   = var.container_name
    host_port        = var.twenty_port
    container_port   = var.twenty_port
    image_wait_secs  = var.image_wait_secs
    max_pull_retries = var.max_pull_retries
  })

  user_data_replace_on_change = true

  root_block_device {
    volume_size = var.root_volume_size
    volume_type = "gp3"
  }

  tags = {
    Name = var.instance_name
  }
}

